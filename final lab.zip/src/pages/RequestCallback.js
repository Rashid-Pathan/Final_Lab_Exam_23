import "./RequestCallback.css";

const RequestCallback = () => {
  return (
    <div className="request-callback">
      <div className="bg" />
      <div className="bg1" />
      <img
        className="pretty-smiling-lady-transperen-icon"
        alt=""
        src="/prettysmilingladytransperentglasseswidesmilewhiteshirtwithheadsetisolatedwhitephotoroom-1@2x.png"
      />
      <div className="request-callback-parent">
        <b className="request-callback1">
          <span>{`Request `}</span>
          <span className="callback">Callback</span>
        </b>
        <div className="btn-parent">
          <div className="btn">
            <div className="request-callback2">request callback</div>
            <img className="btn-child" alt="" src="/arrow-1@2x.png" />
          </div>
          <div className="checkmark">
            <div className="box-parent">
              <div className="box" />
              <img className="checkmark-icon" alt="" src="/checkmark@2x.png" />
            </div>
            <div className="i-authorize-estee-container">
              <span>{`I authorize Estee Advisors Pvt. Ltd. to contact me. This will override registry on the NDNC. `}</span>
              <span className="as-per-sebi">
                As per SEBI guide Lines, minimum investment required is of ₹50
                Lakhs.
              </span>
            </div>
          </div>
          <div className="form">
            <div className="looking-to-invest-in-rs">
              <div className="bg-parent">
                <div className="bg2" />
                <img className="dropdown-icon" alt="" src="/dropdown@2x.png" />
                <div className="select">Select</div>
              </div>
              <div className="looking-to-invest">
                Looking to invest (In Rs.)
              </div>
            </div>
            <div className="mobile-no">
              <div className="bg-parent">
                <div className="bg2" />
                <div className="select">00 (123) 456 78 90</div>
              </div>
              <div className="looking-to-invest">
                <span>{`Mobile No. `}</span>
                <span className="callback">*</span>
              </div>
            </div>
            <div className="email">
              <div className="bg-parent">
                <div className="bg2" />
                <div className="select">john@email.com</div>
              </div>
              <div className="looking-to-invest">
                <span>{`Email `}</span>
                <span className="callback">*</span>
              </div>
            </div>
            <div className="name">
              <div className="bg-parent">
                <div className="bg2" />
                <div className="select">John</div>
              </div>
              <div className="looking-to-invest">
                <span>{`Name `}</span>
                <span className="callback">*</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestCallback;
